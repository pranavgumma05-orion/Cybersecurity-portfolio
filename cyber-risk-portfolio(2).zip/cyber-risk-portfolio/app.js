"use strict";

const LIVE_KEV_URL = "https://raw.githubusercontent.com/cisagov/kev-data/develop/known_exploited_vulnerabilities.json";
const PAGE_SIZE = 8;

const fallbackKev = {
  title: "CISA Catalog of Known Exploited Vulnerabilities",
  catalogVersion: "2026.06.23",
  dateReleased: "2026-06-23T17:00:37.2944Z",
  count: 1627,
  snapshotSubset: true,
  vulnerabilities: [
    { cveID: "CVE-2025-67038", vendorProject: "Lantronix", product: "EDS5000", vulnerabilityName: "Lantronix EDS5000 Code Injection Vulnerability", dateAdded: "2026-06-23", shortDescription: "Code injection could allow arbitrary operating-system commands to execute with root privileges.", requiredAction: "Apply vendor mitigations and prioritize exposed assets.", dueDate: "2026-06-26", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-78", "CWE-94"] },
    { cveID: "CVE-2026-34910", vendorProject: "Ubiquiti", product: "UniFi OS", vulnerabilityName: "Ubiquiti UniFi OS Improper Input Validation Vulnerability", dateAdded: "2026-06-23", shortDescription: "Improper input validation could allow command injection from an actor with network access.", requiredAction: "Apply vendor mitigations and validate network exposure.", dueDate: "2026-06-26", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-20"] },
    { cveID: "CVE-2026-34909", vendorProject: "Ubiquiti", product: "UniFi OS", vulnerabilityName: "Ubiquiti UniFi OS Path Traversal Vulnerability", dateAdded: "2026-06-23", shortDescription: "Path traversal could expose underlying files and accounts.", requiredAction: "Apply vendor mitigations and investigate exposed systems.", dueDate: "2026-06-26", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-22"] },
    { cveID: "CVE-2026-34908", vendorProject: "Ubiquiti", product: "UniFi OS", vulnerabilityName: "Ubiquiti UniFi OS Improper Access Control Vulnerability", dateAdded: "2026-06-23", shortDescription: "Improper access control could allow unauthorized changes.", requiredAction: "Apply vendor mitigations and review access logs.", dueDate: "2026-06-26", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-284"] },
    { cveID: "CVE-2026-20253", vendorProject: "Splunk", product: "Enterprise", vulnerabilityName: "Splunk Enterprise Missing Authentication for Critical Function Vulnerability", dateAdded: "2026-06-18", shortDescription: "An unauthenticated user could create or truncate arbitrary files through a service endpoint.", requiredAction: "Apply vendor mitigations and review affected endpoints.", dueDate: "2026-06-21", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-306"] },
    { cveID: "CVE-2026-48907", vendorProject: "Widget Factory", product: "Joomla Content Editor", vulnerabilityName: "Joomla Content Editor Improper Access Control Vulnerability", dateAdded: "2026-06-16", shortDescription: "Improper access control could allow upload and execution of PHP code.", requiredAction: "Patch or discontinue use when mitigation is unavailable.", dueDate: "2026-06-19", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-284"] },
    { cveID: "CVE-2026-54420", vendorProject: "LiteSpeed", product: "cPanel Plugin", vulnerabilityName: "LiteSpeed cPanel Plugin Symlink Following Vulnerability", dateAdded: "2026-06-15", shortDescription: "A symbolic-link vulnerability affects some shared-hosting configurations.", requiredAction: "Apply vendor fixes and validate shared-hosting exposure.", dueDate: "2026-06-18", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-61"] },
    { cveID: "CVE-2026-20262", vendorProject: "Cisco", product: "Catalyst SD-WAN Manager", vulnerabilityName: "Cisco Catalyst SD-WAN Manager Path Traversal Vulnerability", dateAdded: "2026-06-15", shortDescription: "An authenticated remote attacker could create or overwrite files.", requiredAction: "Apply vendor mitigations and review privileged accounts.", dueDate: "2026-06-29", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-22"] },
    { cveID: "CVE-2026-35273", vendorProject: "Oracle", product: "PeopleSoft Enterprise PeopleTools", vulnerabilityName: "Oracle PeopleSoft Missing Authentication Vulnerability", dateAdded: "2026-06-12", shortDescription: "An unauthenticated network attacker could compromise PeopleTools.", requiredAction: "Apply the vendor security alert immediately and investigate exposure.", dueDate: "2026-06-15", knownRansomwareCampaignUse: "Known", cwes: ["CWE-306"] },
    { cveID: "CVE-2026-10520", vendorProject: "Ivanti", product: "Sentry", vulnerabilityName: "Ivanti Sentry OS Command Injection Vulnerability", dateAdded: "2026-06-11", shortDescription: "A remote unauthenticated user could achieve root-level code execution in exposed configurations.", requiredAction: "Patch immediately and examine unmanaged or internet-reachable appliances.", dueDate: "2026-06-14", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-78"] },
    { cveID: "CVE-2026-11645", vendorProject: "Google", product: "Chromium V8", vulnerabilityName: "Google Chromium V8 Out-of-Bounds Read and Write Vulnerability", dateAdded: "2026-06-09", shortDescription: "A crafted web page could enable arbitrary code execution inside a browser sandbox.", requiredAction: "Apply browser vendor updates.", dueDate: "2026-06-23", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-787", "CWE-125"] },
    { cveID: "CVE-2026-42271", vendorProject: "BerriAI", product: "LiteLLM", vulnerabilityName: "BerriAI LiteLLM Command Injection Vulnerability", dateAdded: "2026-06-08", shortDescription: "An authenticated user could execute arbitrary commands on the host.", requiredAction: "Upgrade to a fixed release and rotate exposed credentials.", dueDate: "2026-06-22", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-78", "CWE-77"] },
    { cveID: "CVE-2026-50751", vendorProject: "Check Point", product: "Security Gateway", vulnerabilityName: "Check Point Security Gateway Improper Authentication Vulnerability", dateAdded: "2026-06-08", shortDescription: "An unauthenticated attacker could bypass user authentication and establish a VPN connection.", requiredAction: "Apply the vendor hotfix and review remote-access logs.", dueDate: "2026-06-11", knownRansomwareCampaignUse: "Known", cwes: ["CWE-287"] },
    { cveID: "CVE-2026-28318", vendorProject: "SolarWinds", product: "Serv-U", vulnerabilityName: "SolarWinds Serv-U Resource Consumption Vulnerability", dateAdded: "2026-06-05", shortDescription: "Crafted unauthenticated requests could crash the service.", requiredAction: "Apply the vendor hotfix and monitor service availability.", dueDate: "2026-06-19", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-400"] },
    { cveID: "CVE-2022-0492", vendorProject: "Linux", product: "Kernel", vulnerabilityName: "Linux Kernel Improper Authentication Vulnerability", dateAdded: "2026-06-02", shortDescription: "A cgroups feature could be abused for privilege escalation.", requiredAction: "Apply vendor kernel updates and validate container hardening.", dueDate: "2026-06-05", knownRansomwareCampaignUse: "Unknown", cwes: ["CWE-287", "CWE-862"] },
    { cveID: "CVE-2026-48027", vendorProject: "Nx", product: "Nx Console", vulnerabilityName: "Nx Console Embedded Malicious Code Vulnerability", dateAdded: "2026-05-27", shortDescription: "A malicious published extension version harvested credentials.", requiredAction: "Remove affected versions, rotate credentials, and review developer endpoints.", dueDate: "2026-06-10", knownRansomwareCampaignUse: "Known", cwes: ["CWE-506"] }
  ]
};

const csfFunctions = [
  { code: "GV", name: "Govern", outcomes: [
    ["GV.OC", "Organizational context", "Mission, stakeholders, dependencies, and legal requirements are understood.", 2],
    ["GV.RM", "Risk management strategy", "Risk appetite, priorities, and decision criteria are defined.", 2],
    ["GV.OV", "Oversight", "Cybersecurity performance and risk decisions receive leadership oversight.", 1]
  ]},
  { code: "ID", name: "Identify", outcomes: [
    ["ID.AM", "Asset management", "Hardware, software, services, systems, and data are inventoried and prioritized.", 2],
    ["ID.RA", "Risk assessment", "Threats, vulnerabilities, likelihood, and impact are evaluated.", 2],
    ["ID.IM", "Improvement", "Lessons from tests and operations drive measurable improvement.", 1]
  ]},
  { code: "PR", name: "Protect", outcomes: [
    ["PR.AA", "Identity, authentication, and access", "Access is limited, reviewed, and strongly authenticated.", 1],
    ["PR.DS", "Data security", "Data is protected according to sensitivity and lifecycle.", 2],
    ["PR.PS", "Platform security", "Configurations, patching, and software integrity are managed.", 2]
  ]},
  { code: "DE", name: "Detect", outcomes: [
    ["DE.CM", "Continuous monitoring", "Networks, endpoints, identities, cloud, and suppliers are monitored.", 2],
    ["DE.AE", "Adverse event analysis", "Events are correlated, scoped, prioritized, and escalated.", 1]
  ]},
  { code: "RS", name: "Respond", outcomes: [
    ["RS.MA", "Incident management", "Incidents are triaged, coordinated, and tracked through closure.", 2],
    ["RS.AN", "Incident analysis", "Root cause, scope, impact, and evidence are determined.", 1],
    ["RS.CO", "Response communications", "Internal and external communications are planned and timely.", 2]
  ]},
  { code: "RC", name: "Recover", outcomes: [
    ["RC.RP", "Recovery execution", "Recovery plans restore services and verify integrity.", 1],
    ["RC.CO", "Recovery communications", "Stakeholders receive coordinated restoration updates.", 2]
  ]}
];

const crosswalk = [
  { theme: "Governance and oversight", csf: "GV.RM, GV.PO, GV.OV", nist: "PM-1, PM-9, PM-28", cis: "Program-wide governance; IG governance mapping", pci: "Requirement 12", soc: "CC1, CC2, CC3, CC4", iso: "Clauses 4–10; A.5.1–A.5.4" },
  { theme: "Asset and software inventory", csf: "ID.AM", nist: "CM-8, PM-5", cis: "Controls 1 and 2", pci: "2.4; scope documentation", soc: "CC6.1, CC7.1", iso: "A.5.9, A.8.1" },
  { theme: "Identity and access management", csf: "PR.AA", nist: "AC-2, AC-3, IA-2, IA-5", cis: "Controls 5 and 6", pci: "Requirements 7 and 8", soc: "CC6.1–CC6.3", iso: "A.5.15–A.5.18" },
  { theme: "Vulnerability and patch management", csf: "ID.RA, PR.PS", nist: "RA-5, SI-2", cis: "Control 7", pci: "Requirements 6 and 11", soc: "CC7.1", iso: "A.8.8" },
  { theme: "Secure configuration", csf: "PR.PS", nist: "CM-2, CM-6, CM-7", cis: "Control 4", pci: "Requirement 2", soc: "CC5.2, CC7.1", iso: "A.8.9" },
  { theme: "Logging and monitoring", csf: "DE.CM, DE.AE", nist: "AU-2, AU-6, SI-4", cis: "Controls 8 and 13", pci: "Requirement 10", soc: "CC7.2–CC7.3", iso: "A.8.15–A.8.16" },
  { theme: "Incident response", csf: "RS.MA, RS.AN, RS.CO, RS.MI", nist: "IR-4, IR-6, IR-8", cis: "Control 17", pci: "12.10", soc: "CC7.4–CC7.5", iso: "A.5.24–A.5.28" },
  { theme: "Backup and resilience", csf: "PR.IR, RC.RP, RC.CO", nist: "CP-2, CP-9, CP-10", cis: "Control 11", pci: "12.10; availability is scope-dependent", soc: "A1.2–A1.3", iso: "A.5.29–A.5.30, A.8.13–A.8.14" },
  { theme: "Cloud and service-provider risk", csf: "GV.SC, PR.DS, PR.PS", nist: "SA-9, SR-3, SC-7", cis: "Controls 3, 12, and 15", pci: "Shared responsibility and scope-dependent requirements", soc: "CC6, CC9", iso: "A.5.19–A.5.23" },
  { theme: "Control testing and assurance", csf: "GV.OV, ID.IM", nist: "CA-2, CA-7, CA-8", cis: "Controls 8, 17, and 18", pci: "Requirements 10–12", soc: "TSC evidence and examination procedures", iso: "Clause 9.2; A.5.35–A.5.36" }
];

const state = {
  kev: fallbackKev,
  liveKev: false,
  filteredKev: [],
  kevPage: 1,
  csfOverall: 0,
  csfFunctionScores: {},
  iamScore: null,
  iamFindings: []
};

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function safeDate(value) {
  const date = new Date(`${value}T12:00:00`);
  return Number.isNaN(date.valueOf()) ? null : date;
}

function daysBetween(a, b) {
  return Math.floor((b - a) / 86400000);
}

function priorityScore(item) {
  const today = new Date();
  today.setHours(12, 0, 0, 0);
  const added = safeDate(item.dateAdded);
  const due = safeDate(item.dueDate);
  let score = 0;
  if (item.knownRansomwareCampaignUse === "Known") score += 50;
  if (due && due <= today) score += 30;
  if (added && daysBetween(added, today) <= 14) score += 20;
  const searchable = `${item.product} ${item.vulnerabilityName} ${item.shortDescription}`.toLowerCase();
  if (/(vpn|gateway|authentication|identity|browser|remote|internet|cloud|firewall|router|sso)/.test(searchable)) score += 10;
  return Math.min(score, 100);
}

function priorityLabel(score) {
  if (score >= 80) return ["Critical", "priority-critical"];
  if (score >= 55) return ["High", "priority-high"];
  if (score >= 30) return ["Medium", "priority-medium"];
  return ["Routine", "priority-low"];
}

function formatDate(value) {
  const date = safeDate(value);
  return date ? new Intl.DateTimeFormat("en-US", { month: "short", day: "numeric", year: "numeric" }).format(date) : "—";
}

function initializeNav() {
  const toggle = $(".nav-toggle");
  const nav = $(".primary-nav");
  toggle?.addEventListener("click", () => {
    const open = nav.classList.toggle("is-open");
    toggle.setAttribute("aria-expanded", String(open));
  });
  $$(".primary-nav a").forEach(link => link.addEventListener("click", () => {
    nav.classList.remove("is-open");
    toggle?.setAttribute("aria-expanded", "false");
  }));
}

function initializeTabs() {
  $$(".project-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      $$(".project-tab").forEach(item => {
        item.classList.toggle("is-active", item === tab);
        item.setAttribute("aria-selected", String(item === tab));
      });
      $$(".project-panel").forEach(panel => {
        const active = panel.id === tab.dataset.target;
        panel.classList.toggle("is-active", active);
        panel.hidden = !active;
      });
    });
  });
}

async function loadKevData() {
  const status = $("#kev-status");

  // Render verified embedded data immediately so the dashboard is useful even
  // inside file previews, offline browsers, or environments that block fetch().
  state.kev = fallbackKev;
  state.liveKev = false;
  status.classList.remove("is-error");
  status.innerHTML = `<span class="status-dot"></span><span>Verified CISA snapshot loaded • catalog ${fallbackKev.catalogVersion}. Checking for a newer live catalog…</span>`;
  renderKevDashboard();

  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 3500);
  try {
    const response = await fetch(LIVE_KEV_URL, { cache: "no-store", signal: controller.signal });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const data = await response.json();
    if (!Array.isArray(data.vulnerabilities) || data.vulnerabilities.length < 1) throw new Error("Unexpected data format");
    state.kev = data;
    state.liveKev = true;
    status.classList.remove("is-error");
    status.innerHTML = `<span class="status-dot"></span><span>Live CISA KEV catalog loaded • version ${escapeHtml(data.catalogVersion || "current")} • released ${escapeHtml(formatDate((data.dateReleased || "").slice(0, 10)))}</span>`;
    renderKevDashboard();
  } catch (error) {
    state.kev = fallbackKev;
    state.liveKev = false;
    status.classList.add("is-error");
    status.innerHTML = `<span class="status-dot"></span><span>Live source is blocked or unavailable here. The dashboard remains fully functional with a verified ${fallbackKev.vulnerabilities.length}-record CISA snapshot from catalog ${fallbackKev.catalogVersion}.</span>`;
    renderKevDashboard();
    console.warn("CISA live data unavailable; using fallback snapshot.", error);
  } finally {
    clearTimeout(timeout);
  }
}

function renderKevDashboard() {
  const vulnerabilities = state.kev.vulnerabilities || [];
  const today = new Date();
  today.setHours(12, 0, 0, 0);
  const recent = vulnerabilities.filter(item => {
    const date = safeDate(item.dateAdded);
    return date && daysBetween(date, today) <= 30;
  }).length;
  const overdue = vulnerabilities.filter(item => {
    const date = safeDate(item.dueDate);
    return date && date < today;
  }).length;
  const ransomware = vulnerabilities.filter(item => item.knownRansomwareCampaignUse === "Known").length;

  $("#metric-total").textContent = state.liveKev ? String(state.kev.count || vulnerabilities.length) : String(vulnerabilities.length);
  $("#metric-version").textContent = state.liveKev ? `Catalog ${state.kev.catalogVersion || "current"}` : `Snapshot subset • source catalog ${state.kev.count}`;
  $("#metric-ransomware").textContent = String(ransomware);
  $("#metric-recent").textContent = String(recent);
  $("#metric-overdue").textContent = String(overdue);

  const vendorSelect = $("#vendor-filter");
  const current = vendorSelect.value;
  const vendors = [...new Set(vulnerabilities.map(item => item.vendorProject).filter(Boolean))].sort((a, b) => a.localeCompare(b));
  vendorSelect.innerHTML = `<option value="all">All vendors</option>${vendors.map(vendor => `<option value="${escapeAttribute(vendor)}">${escapeHtml(vendor)}</option>`).join("")}`;
  if (vendors.includes(current)) vendorSelect.value = current;

  renderVendorBars(vulnerabilities);
  applyKevFilters();
}

function applyKevFilters() {
  const vendor = $("#vendor-filter").value;
  const ransomware = $("#ransomware-filter").value;
  const query = $("#kev-search").value.trim().toLowerCase();
  state.filteredKev = (state.kev.vulnerabilities || [])
    .filter(item => vendor === "all" || item.vendorProject === vendor)
    .filter(item => ransomware === "all" || item.knownRansomwareCampaignUse === ransomware)
    .filter(item => !query || `${item.cveID} ${item.vendorProject} ${item.product} ${item.vulnerabilityName}`.toLowerCase().includes(query))
    .map(item => ({ ...item, calculatedPriority: priorityScore(item) }))
    .sort((a, b) => b.calculatedPriority - a.calculatedPriority || String(b.dateAdded).localeCompare(String(a.dateAdded)));
  state.kevPage = 1;
  renderKevTable();
}

function renderKevTable() {
  const body = $("#kev-table-body");
  const totalPages = Math.max(1, Math.ceil(state.filteredKev.length / PAGE_SIZE));
  state.kevPage = Math.min(state.kevPage, totalPages);
  const start = (state.kevPage - 1) * PAGE_SIZE;
  const pageItems = state.filteredKev.slice(start, start + PAGE_SIZE);

  if (!pageItems.length) {
    body.innerHTML = `<tr><td colspan="6">No entries match the current filters.</td></tr>`;
  } else {
    body.innerHTML = pageItems.map(item => {
      const [label, cssClass] = priorityLabel(item.calculatedPriority);
      return `<tr>
        <td><span class="priority-pill ${cssClass}">${label} ${item.calculatedPriority}</span></td>
        <td><strong>${escapeHtml(item.cveID)}</strong><small>${escapeHtml(item.vendorProject)} • ${escapeHtml(item.product)}</small></td>
        <td>${escapeHtml(formatDate(item.dateAdded))}</td>
        <td>${escapeHtml(formatDate(item.dueDate))}</td>
        <td>${escapeHtml(item.knownRansomwareCampaignUse || "Unknown")}</td>
        <td><a href="https://nvd.nist.gov/vuln/detail/${encodeURIComponent(item.cveID)}" target="_blank" rel="noreferrer">Review CVE</a></td>
      </tr>`;
    }).join("");
  }

  $("#kev-page-label").textContent = `Page ${state.kevPage} of ${totalPages} • ${state.filteredKev.length} results`;
  $("#kev-prev").disabled = state.kevPage <= 1;
  $("#kev-next").disabled = state.kevPage >= totalPages;
}

function renderVendorBars(vulnerabilities) {
  const counts = new Map();
  vulnerabilities.forEach(item => counts.set(item.vendorProject || "Unknown", (counts.get(item.vendorProject || "Unknown") || 0) + 1));
  const top = [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
  const max = Math.max(1, ...top.map(([, count]) => count));
  $("#vendor-bars").innerHTML = top.map(([vendor, count]) => `<div class="bar-row"><span title="${escapeAttribute(vendor)}">${escapeHtml(vendor)}</span><div class="bar-track"><div class="bar-fill" style="width:${Math.round((count / max) * 100)}%"></div></div><b>${count}</b></div>`).join("");
}

function initializeKevControls() {
  ["#vendor-filter", "#ransomware-filter"].forEach(selector => $(selector).addEventListener("change", applyKevFilters));
  $("#kev-search").addEventListener("input", applyKevFilters);
  $("#kev-prev").addEventListener("click", () => { state.kevPage -= 1; renderKevTable(); });
  $("#kev-next").addEventListener("click", () => { state.kevPage += 1; renderKevTable(); });
}

function renderCsfControls() {
  const container = $("#csf-controls");
  container.innerHTML = csfFunctions.map(func => `<section class="csf-function" data-function="${func.code}">
    <div class="csf-function-header"><strong>${escapeHtml(func.name)}</strong><span>${func.code}</span></div>
    <div class="csf-outcomes">${func.outcomes.map(([code, name, description, initial]) => `<div class="csf-outcome">
      <div><strong>${escapeHtml(code)} • ${escapeHtml(name)}</strong><small>${escapeHtml(description)}</small></div>
      <div class="range-wrap"><input type="range" min="0" max="4" step="1" value="${initial}" data-csf-code="${code}" aria-label="${escapeAttribute(name)} maturity score"><span class="range-value">${initial}</span></div>
    </div>`).join("")}</div>
  </section>`).join("");

  $$('[data-csf-code]').forEach(range => range.addEventListener("input", event => {
    event.target.nextElementSibling.textContent = event.target.value;
    calculateCsfScores();
  }));
  calculateCsfScores();
}

function calculateCsfScores() {
  const functionScores = {};
  csfFunctions.forEach(func => {
    const values = func.outcomes.map(([code]) => Number($(`[data-csf-code="${code}"]`).value));
    functionScores[func.code] = values.reduce((sum, value) => sum + value, 0) / values.length;
  });
  const all = $$('[data-csf-code]').map(input => Number(input.value));
  const overall = all.reduce((sum, value) => sum + value, 0) / all.length;
  state.csfOverall = overall;
  state.csfFunctionScores = functionScores;

  $("#overall-score").textContent = overall.toFixed(1);
  const degrees = (overall / 4) * 360;
  $("#score-ring").style.background = `conic-gradient(var(--accent) ${degrees}deg, rgba(255,255,255,.08) ${degrees}deg)`;
  const maturity = maturityText(overall);
  $("#maturity-label").textContent = maturity.label;
  $("#maturity-summary").textContent = maturity.summary;
  $("#function-scores").innerHTML = csfFunctions.map(func => {
    const score = functionScores[func.code];
    return `<div class="function-score"><span>${func.name}</span><div class="bar-track"><div class="bar-fill" style="width:${(score / 4) * 100}%"></div></div><b>${score.toFixed(1)}</b></div>`;
  }).join("");
}

function maturityText(score) {
  if (score < 1) return { label: "Initial", summary: "Practices are mostly informal, reactive, or undocumented." };
  if (score < 2) return { label: "Developing", summary: "Core practices exist, but consistency and evidence are limited." };
  if (score < 3) return { label: "Defined", summary: "Processes are documented and repeatable across much of the environment." };
  if (score < 3.6) return { label: "Managed", summary: "Performance is measured, governed, and actively improved." };
  return { label: "Adaptive", summary: "Risk information and lessons learned continuously shape decisions." };
}

function buildRoadmap() {
  const outcomes = csfFunctions.flatMap(func => func.outcomes.map(([code, name, description]) => ({
    func: func.name,
    code,
    name,
    description,
    score: Number($(`[data-csf-code="${code}"]`).value)
  })));
  const sorted = outcomes.sort((a, b) => a.score - b.score || a.code.localeCompare(b.code));
  const phases = [
    { label: "Days 0–30", items: sorted.slice(0, 3) },
    { label: "Days 31–60", items: sorted.slice(3, 6) },
    { label: "Days 61–90", items: sorted.slice(6, 9) }
  ];
  $("#roadmap-output").innerHTML = phases.map(phase => `<div class="roadmap-phase"><strong>${phase.label}</strong><ul>${phase.items.map(item => `<li><b>${escapeHtml(item.code)} ${escapeHtml(item.name)}:</b> raise the current score of ${item.score} by assigning an owner, defining evidence, and implementing a measurable target.</li>`).join("")}</ul></div>`).join("");
  $("#roadmap-card").hidden = false;
  $("#roadmap-card").scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function initializeCsf() {
  renderCsfControls();
  $("#generate-roadmap").addEventListener("click", buildRoadmap);
  $("#copy-roadmap").addEventListener("click", async () => {
    const text = $("#roadmap-output").innerText;
    await copyText(text);
    $("#copy-roadmap").textContent = "Copied";
    setTimeout(() => { $("#copy-roadmap").textContent = "Copy"; }, 1400);
  });
}

const demoPolicy = {
  Version: "2012-10-17",
  Statement: [
    {
      Sid: "AdminLikeAccess",
      Effect: "Allow",
      Action: ["iam:PassRole", "iam:CreatePolicyVersion", "lambda:UpdateFunctionCode", "s3:*"],
      Resource: "*"
    },
    {
      Sid: "ReadCloudTrail",
      Effect: "Allow",
      Action: ["cloudtrail:LookupEvents"],
      Resource: "*"
    }
  ]
};

function normalizeArray(value) {
  if (value === undefined || value === null) return [];
  return Array.isArray(value) ? value : [value];
}

function analyzeIamPolicy(policy) {
  const findings = [];
  let score = 0;
  if (policy.Version !== "2012-10-17") {
    findings.push({ severity: "medium", title: "Policy language version is missing or unexpected", detail: "Use the current IAM policy language version unless a documented exception is required.", evidence: `Version: ${policy.Version || "not present"}` });
    score += 8;
  }
  const statements = normalizeArray(policy.Statement);
  if (!statements.length) {
    return { score: 0, findings: [{ severity: "low", title: "No permission statements found", detail: "The document does not currently grant permissions.", evidence: "Statement array is empty." }] };
  }

  const privilegeActions = [
    "iam:passrole", "iam:createpolicyversion", "iam:setdefaultpolicyversion", "iam:attachuserpolicy", "iam:attachrolepolicy",
    "iam:putuserpolicy", "iam:putrolepolicy", "iam:createaccesskey", "lambda:updatefunctioncode", "lambda:createfunction",
    "ec2:runinstances", "cloudformation:createstack", "sts:assumerole"
  ];

  statements.forEach((statement, index) => {
    const effect = String(statement.Effect || "").toLowerCase();
    if (effect !== "allow") return;
    const actions = normalizeArray(statement.Action).map(value => String(value).toLowerCase());
    const resources = normalizeArray(statement.Resource).map(value => String(value));
    const sid = statement.Sid || `Statement ${index + 1}`;

    if (actions.includes("*") || actions.some(action => /^([a-z0-9-]+):\*$/.test(action))) {
      findings.push({ severity: actions.includes("*") ? "critical" : "high", title: "Broad wildcard permissions", detail: "Wildcard actions can allow far more capability than the workload requires.", evidence: `${sid}: ${actions.filter(action => action === "*" || action.endsWith(":*")).join(", ")}` });
      score += actions.includes("*") ? 35 : 22;
    }
    if (resources.includes("*")) {
      findings.push({ severity: "high", title: "Permissions apply to all resources", detail: "Restrict resources to specific ARNs whenever the service supports resource-level permissions.", evidence: `${sid}: Resource is *` });
      score += 20;
    }
    const escalations = actions.filter(action => privilegeActions.includes(action));
    if (escalations.length) {
      findings.push({ severity: "critical", title: "Potential privilege-escalation path", detail: "These actions can create or pass identities, modify code, or launch resources under more privileged execution roles.", evidence: `${sid}: ${escalations.join(", ")}` });
      score += 30;
    }
    if (actions.includes("iam:passrole")) {
      findings.push({ severity: "high", title: "PassRole requires strict constraints", detail: "Limit iam:PassRole to named roles and pair it with service conditions where possible.", evidence: `${sid}: iam:PassRole` });
      score += 15;
    }
    if (!statement.Condition && (resources.includes("*") || actions.some(action => action.endsWith(":*")))) {
      findings.push({ severity: "medium", title: "No conditional guardrails", detail: "Conditions can restrict source network, organization, account, region, MFA status, resource tags, or requested service.", evidence: `${sid}: no Condition block` });
      score += 8;
    }
    if (statement.NotAction || statement.NotResource) {
      findings.push({ severity: "high", title: "Negated permission element requires review", detail: "NotAction and NotResource can create unintentionally broad access when combined with Allow.", evidence: `${sid}: ${statement.NotAction ? "NotAction" : ""} ${statement.NotResource ? "NotResource" : ""}`.trim() });
      score += 18;
    }
  });

  if (!findings.length) findings.push({ severity: "low", title: "No obvious high-risk patterns detected", detail: "This static review did not identify common broad-permission patterns. Validate service-specific semantics, trust policies, permission boundaries, SCPs, and actual access paths.", evidence: "Static pattern analysis only." });
  return { score: Math.min(100, score), findings };
}

function renderIamResult(result) {
  state.iamScore = result.score;
  state.iamFindings = result.findings;
  $("#iam-score").textContent = String(result.score);
  const badge = $("#iam-risk-badge");
  badge.className = "risk-badge";
  let label = "Low";
  let cssClass = "risk-low";
  if (result.score >= 75) { label = "Critical"; cssClass = "risk-critical"; }
  else if (result.score >= 50) { label = "High"; cssClass = "risk-high"; }
  else if (result.score >= 25) { label = "Medium"; cssClass = "risk-medium"; }
  badge.textContent = `${label} risk`;
  badge.classList.add(cssClass);
  const template = $("#finding-template");
  const container = $("#iam-findings");
  container.innerHTML = "";
  result.findings.forEach(finding => {
    const node = template.content.cloneNode(true);
    const article = $(".finding", node);
    article.classList.add(`severity-${finding.severity}`);
    $("strong", node).textContent = finding.title;
    $("p", node).textContent = finding.detail;
    $("small", node).textContent = finding.evidence;
    container.appendChild(node);
  });
}

function initializeIam() {
  $("#load-demo-policy").addEventListener("click", () => {
    $("#iam-policy").value = JSON.stringify(demoPolicy, null, 2);
  });
  $("#analyze-policy").addEventListener("click", () => {
    try {
      const policy = JSON.parse($("#iam-policy").value);
      renderIamResult(analyzeIamPolicy(policy));
    } catch (error) {
      renderIamResult({ score: 0, findings: [{ severity: "critical", title: "Invalid JSON", detail: "Correct the policy syntax before evaluating permissions.", evidence: error.message }] });
    }
  });
}

function renderCrosswalk(filter = "all") {
  const rows = filter === "all" ? crosswalk : crosswalk.filter(row => row.theme === filter);
  $("#crosswalk-body").innerHTML = rows.map(row => `<tr><td>${escapeHtml(row.theme)}</td><td>${escapeHtml(row.csf)}</td><td>${escapeHtml(row.nist)}</td><td>${escapeHtml(row.cis)}</td><td>${escapeHtml(row.pci)}</td><td>${escapeHtml(row.soc)}</td><td>${escapeHtml(row.iso)}</td></tr>`).join("");
}

function initializeCrosswalk() {
  const filter = $("#crosswalk-filter");
  filter.innerHTML = `<option value="all">All themes</option>${crosswalk.map(row => `<option value="${escapeAttribute(row.theme)}">${escapeHtml(row.theme)}</option>`).join("")}`;
  filter.addEventListener("change", () => renderCrosswalk(filter.value));
  $("#export-crosswalk").addEventListener("click", () => {
    const headers = ["Security theme", "NIST CSF 2.0", "NIST SP 800-53", "CIS Controls v8.1", "PCI DSS v4.0.1", "SOC 2", "ISO/IEC 27001"];
    const rows = crosswalk.map(row => [row.theme, row.csf, row.nist, row.cis, row.pci, row.soc, row.iso]);
    const csv = [headers, ...rows].map(row => row.map(csvEscape).join(",")).join("\n");
    downloadText("cybersecurity-control-crosswalk.csv", csv, "text/csv;charset=utf-8");
  });
  renderCrosswalk();
}

function buildExecutiveBrief() {
  const org = $("#report-org").value.trim() || "Organization";
  const audience = $("#report-audience").value;
  const focus = $("#report-focus").value;
  const context = $("#report-context").value.trim();
  const vulnerabilities = state.kev.vulnerabilities || [];
  const sorted = vulnerabilities.map(item => ({ ...item, calculatedPriority: priorityScore(item) })).sort((a, b) => b.calculatedPriority - a.calculatedPriority);
  const top = sorted.slice(0, 3);
  const ransomware = vulnerabilities.filter(item => item.knownRansomwareCampaignUse === "Known").length;
  const lowestFunction = Object.entries(state.csfFunctionScores).sort((a, b) => a[1] - b[1])[0] || ["PR", 0];
  const functionName = csfFunctions.find(func => func.code === lowestFunction[0])?.name || lowestFunction[0];
  const generated = new Intl.DateTimeFormat("en-US", { month: "long", day: "numeric", year: "numeric" }).format(new Date());

  const report = $("#executive-report");
  report.innerHTML = `
    <div class="report-head">
      <div><p>CYBER RISK BRIEF</p><h3>${escapeHtml(org)}</h3><small>Prepared for ${escapeHtml(audience)}</small></div>
      <div><small>${escapeHtml(generated)}</small><p>${escapeHtml(focus)}</p></div>
    </div>
    <section class="report-section">
      <h4>Executive assessment</h4>
      <p>${escapeHtml(context)} The current portfolio analysis indicates that actively exploited vulnerabilities and uneven control maturity should be managed as business-resilience issues rather than isolated technical defects.</p>
      <div class="report-callout"><strong>Decision requested:</strong> confirm accountable owners for urgent remediation, approve a 30-day validation cycle, and require evidence that critical exposure has been removed or formally accepted.</div>
    </section>
    <section class="report-section">
      <h4>What leadership should know</h4>
      <ul>
        <li>The loaded CISA dataset contains <strong>${state.liveKev ? escapeHtml(String(state.kev.count || vulnerabilities.length)) : `${vulnerabilities.length} displayed snapshot records`}</strong>, including <strong>${ransomware}</strong> entries marked for known ransomware campaign use in the loaded data.</li>
        <li>The NIST CSF demo assessment currently scores <strong>${state.csfOverall.toFixed(1)} of 4.0</strong>; the lowest function is <strong>${escapeHtml(functionName)}</strong> at ${Number(lowestFunction[1]).toFixed(1)}.</li>
        <li>${state.iamScore === null ? "No IAM policy result has been incorporated yet." : `The IAM policy review produced a risk score of <strong>${state.iamScore}/100</strong> with ${state.iamFindings.length} findings.`}</li>
      </ul>
    </section>
    <section class="report-section">
      <h4>Immediate technical priorities</h4>
      <ul>${top.map(item => `<li><strong>${escapeHtml(item.cveID)} — ${escapeHtml(item.vendorProject)} ${escapeHtml(item.product)}:</strong> priority score ${item.calculatedPriority}; validate ownership, exposure, patch status, and compensating controls.</li>`).join("")}</ul>
    </section>
    <section class="report-section">
      <h4>30-day management actions</h4>
      <ul>
        <li>Require asset owners to reconcile CISA KEV entries against the hardware, software, cloud-service, and internet-exposure inventories.</li>
        <li>Close the weakest CSF function through named ownership, target-state evidence, and weekly reporting on overdue actions.</li>
        <li>Review privileged identities, wildcard cloud permissions, dormant accounts, MFA coverage, role-passing rights, and emergency access.</li>
        <li>Provide leadership with exception decisions that identify business impact, expiration date, compensating controls, and accountable approver.</li>
      </ul>
    </section>
    <div class="report-actions"><button class="button button-ghost button-small" id="copy-report" type="button">Copy brief</button><button class="button button-small" id="print-report" type="button">Print / save PDF</button></div>`;

  $("#copy-report").addEventListener("click", async event => {
    await copyText(report.innerText.replace("Copy briefPrint / save PDF", ""));
    event.target.textContent = "Copied";
    setTimeout(() => { event.target.textContent = "Copy brief"; }, 1400);
  });
  $("#print-report").addEventListener("click", () => window.print());
}

function initializeReport() {
  $("#build-report").addEventListener("click", buildExecutiveBrief);
}

async function copyText(text) {
  if (navigator.clipboard && window.isSecureContext) {
    await navigator.clipboard.writeText(text);
    return;
  }
  const textarea = document.createElement("textarea");
  textarea.value = text;
  textarea.setAttribute("readonly", "");
  textarea.style.position = "fixed";
  textarea.style.opacity = "0";
  document.body.appendChild(textarea);
  textarea.select();
  document.execCommand("copy");
  textarea.remove();
}

function csvEscape(value) {
  return `"${String(value).replaceAll('"', '""')}"`;
}

function downloadText(filename, content, type) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function escapeHtml(value) {
  return String(value ?? "").replace(/[&<>'"]/g, character => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" })[character]);
}

function escapeAttribute(value) {
  return escapeHtml(value).replaceAll("`", "&#96;");
}


function initializeVisualPolish() {
  const revealTargets = document.querySelectorAll(
    ".section-heading, .project-tabs, .project-panel, .method-grid article, .source-grid a, .contact-cta-card"
  );

  if (!("IntersectionObserver" in window) || window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
    revealTargets.forEach(element => element.classList.add("is-visible"));
    return;
  }

  revealTargets.forEach((element, index) => {
    element.classList.add("reveal");
    element.style.transitionDelay = `${Math.min(index % 5, 4) * 45}ms`;
  });

  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      entry.target.classList.add("is-visible");
      observer.unobserve(entry.target);
    });
  }, { threshold: 0.12, rootMargin: "0px 0px -40px" });

  revealTargets.forEach(element => observer.observe(element));

  const heroPanel = document.querySelector(".hero-panel");
  if (heroPanel && window.matchMedia("(pointer: fine)").matches) {
    heroPanel.addEventListener("pointermove", event => {
      const bounds = heroPanel.getBoundingClientRect();
      const x = (event.clientX - bounds.left) / bounds.width - 0.5;
      const y = (event.clientY - bounds.top) / bounds.height - 0.5;
      heroPanel.style.transform = `perspective(1100px) rotateX(${(-y * 3).toFixed(2)}deg) rotateY(${(x * 4).toFixed(2)}deg) rotateZ(1.1deg)`;
    });
    heroPanel.addEventListener("pointerleave", () => {
      heroPanel.style.transform = "rotate(1.1deg)";
    });
  }
}

function initialize() {
  initializeNav();
  initializeTabs();
  initializeKevControls();
  initializeCsf();
  initializeIam();
  initializeCrosswalk();
  initializeReport();
  initializeVisualPolish();
  loadKevData();
}

document.addEventListener("DOMContentLoaded", initialize);
