# Pranav Gumma Cyber Risk Consulting Lab

A polished, interactive cybersecurity portfolio built as a **single self-contained HTML file**. CSS, JavaScript, fallback data, and all interactive project logic are embedded directly in `index.html`, so the design works when the file is opened in ChatGPT, from a local computer, or on static hosting.

## Open locally

Double-click `index.html` or `pranav-cyber-risk-portfolio.html`.

## Publish with GitHub Pages

1. Create a new GitHub repository.
2. Upload `index.html` to the repository root.
3. Open **Settings → Pages**.
4. Choose **Deploy from a branch**, select `main`, and choose `/ (root)`.
5. Save and wait for the public URL.

## Publish with Netlify

Drag `index.html` into Netlify Drop, or upload this entire folder.

## Data and privacy

The live vulnerability dashboard requests the official CISA Known Exploited Vulnerabilities JSON feed. When external network requests are unavailable, the website uses a clearly identified verified snapshot embedded in the page. IAM policy analysis runs entirely in the browser and does not upload policy content.

## Included projects

- CISA KEV vulnerability prioritization dashboard
- NIST CSF 2.0 maturity assessment and roadmap
- AWS IAM policy risk analyzer
- Executive cyber-risk brief generator
- Security framework crosswalk and CSV export

This is an educational portfolio and does not represent a formal audit, certification, attestation, legal opinion, or client engagement.
